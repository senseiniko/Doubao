package com.example.petmanagement.mapper;

import com.example.petmanagement.entity.Pet;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface PetMapper {
    List<Pet> findAll();
    Pet findById(Integer id);
    List<Pet> findByCondition(Map<String, Object> condition);
    int insert(Pet pet);
    int update(Pet pet);
    int delete(Integer id);
}    