package com.example.petmanagement.service;

import com.example.petmanagement.entity.User;

public interface UserService {
    User findByUsername(String username);
    boolean register(User user);
    boolean login(String username, String password);
}    