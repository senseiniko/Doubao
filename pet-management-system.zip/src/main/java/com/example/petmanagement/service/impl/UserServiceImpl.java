package com.example.petmanagement.service.impl;

import com.example.petmanagement.entity.User;
import com.example.petmanagement.mapper.UserMapper;
import com.example.petmanagement.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public User findByUsername(String username) {
        return userMapper.findByUsername(username);
    }

    @Override
    public boolean register(User user) {
        User existingUser = findByUsername(user.getUsername());
        if (existingUser != null) {
            return false; // 用户名已存在
        }
        int result = userMapper.insertUser(user);
        return result > 0;
    }

    @Override
    public boolean login(String username, String password) {
        User user = findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            return true;
        }
        return false;
    }
}    