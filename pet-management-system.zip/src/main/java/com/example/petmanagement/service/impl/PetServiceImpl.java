package com.example.petmanagement.service.impl;

import com.example.petmanagement.entity.Pet;
import com.example.petmanagement.mapper.PetMapper;
import com.example.petmanagement.service.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class PetServiceImpl implements PetService {

    @Autowired
    private PetMapper petMapper;

    @Override
    public List<Pet> findAll() {
        return petMapper.findAll();
    }

    @Override
    public Pet findById(Integer id) {
        return petMapper.findById(id);
    }

    @Override
    public List<Pet> findByCondition(Map<String, Object> condition) {
        return petMapper.findByCondition(condition);
    }

    @Override
    public boolean addPet(Pet pet) {
        int result = petMapper.insert(pet);
        return result > 0;
    }

    @Override
    public boolean updatePet(Pet pet) {
        int result = petMapper.update(pet);
        return result > 0;
    }

    @Override
    public boolean deletePet(Integer id) {
        int result = petMapper.delete(id);
        return result > 0;
    }
}    