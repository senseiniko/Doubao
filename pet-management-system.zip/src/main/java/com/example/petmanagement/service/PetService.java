package com.example.petmanagement.service;

import com.example.petmanagement.entity.Pet;

import java.util.List;
import java.util.Map;

public interface PetService {
    List<Pet> findAll();
    Pet findById(Integer id);
    List<Pet> findByCondition(Map<String, Object> condition);
    boolean addPet(Pet pet);
    boolean updatePet(Pet pet);
    boolean deletePet(Integer id);
}    