package com.example.petmanagement.controller;

import com.example.petmanagement.entity.User;
import com.example.petmanagement.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/register")
    public String showRegisterForm() {
        return "user/register";
    }

    @PostMapping("/register")
    public String register(@ModelAttribute User user, Model model) {
        boolean success = userService.register(user);
        if (success) {
            return "redirect:/user/login";
        } else {
            model.addAttribute("error", "注册失败，用户名已存在");
            return "user/register";
        }
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "user/login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password,
                        HttpServletRequest request, Model model) {
        boolean success = userService.login(username, password);
        if (success) {
            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            return "redirect:/pet/list";
        } else {
            model.addAttribute("error", "登录失败，用户名或密码错误");
            return "user/login";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return "redirect:/user/login";
    }

    @GetMapping("/profile")
    public String showProfile(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            return "redirect:/user/login";
        }
        String username = (String) session.getAttribute("username");
        User user = userService.findByUsername(username);
        model.addAttribute("user", user);
        return "user/profile";
    }
}    