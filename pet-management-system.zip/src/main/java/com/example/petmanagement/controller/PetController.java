package com.example.petmanagement.controller;

import com.example.petmanagement.entity.Pet;
import com.example.petmanagement.service.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/pet")
public class PetController {

    @Autowired
    private PetService petService;

    @GetMapping("/list")
    public String list(Model model, HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            return "redirect:/user/login";
        }

        List<Pet> pets = petService.findAll();
        model.addAttribute("pets", pets);
        return "pet/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model, HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            return "redirect:/user/login";
        }

        model.addAttribute("pet", new Pet());
        return "pet/add";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute Pet pet, HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            return "redirect:/user/login";
        }

        boolean success = petService.addPet(pet);
        if (success) {
            return "redirect:/pet/list";
        } else {
            return "pet/add";
        }
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model, HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            return "redirect:/user/login";
        }

        Pet pet = petService.findById(id);
        model.addAttribute("pet", pet);
        return "pet/edit";
    }

    @PostMapping("/edit")
    public String edit(@ModelAttribute Pet pet, HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            return "redirect:/user/login";
        }

        boolean success = petService.updatePet(pet);
        if (success) {
            return "redirect:/pet/list";
        } else {
            return "pet/edit";
        }
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Integer id, HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            return "redirect:/user/login";
        }

        petService.deletePet(id);
        return "redirect:/pet/list";
    }

    @GetMapping("/search")
    public String search(@RequestParam(required = false) String name,
                         @RequestParam(required = false) String type,
                         Model model, HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            return "redirect:/user/login";
        }

        Map<String, Object> condition = new HashMap<>();
        if (name != null && !name.isEmpty()) {
            condition.put("name", name);
        }
        if (type != null && !type.isEmpty()) {
            condition.put("type", type);
        }

        List<Pet> pets = petService.findByCondition(condition);
        model.addAttribute("pets", pets);
        return "pet/list";
    }
}    