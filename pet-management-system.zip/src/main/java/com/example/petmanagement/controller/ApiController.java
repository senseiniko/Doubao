package com.example.petmanagement.controller;

import com.example.petmanagement.entity.Pet;
import com.example.petmanagement.service.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ApiController {

    @Autowired
    private PetService petService;

    @GetMapping("/pets")
    public Map<String, Object> getPets(@RequestParam(required = false) String name,
                                        @RequestParam(required = false) String type) {
        Map<String, Object> result = new HashMap<>();
        try {
            Map<String, Object> condition = new HashMap<>();
            if (name != null && !name.isEmpty()) {
                condition.put("name", name);
            }
            if (type != null && !type.isEmpty()) {
                condition.put("type", type);
            }

            List<Pet> pets = petService.findByCondition(condition);
            result.put("code", 200);
            result.put("message", "查询成功");
            result.put("data", pets);
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "查询失败: " + e.getMessage());
        }
        return result;
    }

    @GetMapping("/pets/{id}")
    public Map<String, Object> getPet(@PathVariable Integer id) {
        Map<String, Object> result = new HashMap<>();
        try {
            Pet pet = petService.findById(id);
            if (pet != null) {
                result.put("code", 200);
                result.put("message", "查询成功");
                result.put("data", pet);
            } else {
                result.put("code", 404);
                result.put("message", "未找到该宠物");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "查询失败: " + e.getMessage());
        }
        return result;
    }

    @PostMapping("/pets")
    public Map<String, Object> addPet(@RequestBody Pet pet) {
        Map<String, Object> result = new HashMap<>();
        try {
            boolean success = petService.addPet(pet);
            if (success) {
                result.put("code", 200);
                result.put("message", "添加成功");
            } else {
                result.put("code", 500);
                result.put("message", "添加失败");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "添加失败: " + e.getMessage());
        }
        return result;
    }

    @PutMapping("/pets/{id}")
    public Map<String, Object> updatePet(@PathVariable Integer id, @RequestBody Pet pet) {
        Map<String, Object> result = new HashMap<>();
        try {
            Pet existingPet = petService.findById(id);
            if (existingPet == null) {
                result.put("code", 404);
                result.put("message", "未找到该宠物");
                return result;
            }

            pet.setId(id);
            boolean success = petService.updatePet(pet);
            if (success) {
                result.put("code", 200);
                result.put("message", "更新成功");
            } else {
                result.put("code", 500);
                result.put("message", "更新失败");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "更新失败: " + e.getMessage());
        }
        return result;
    }

    @DeleteMapping("/pets/{id}")
    public Map<String, Object> deletePet(@PathVariable Integer id) {
        Map<String, Object> result = new HashMap<>();
        try {
            boolean success = petService.deletePet(id);
            if (success) {
                result.put("code", 200);
                result.put("message", "删除成功");
            } else {
                result.put("code", 404);
                result.put("message", "未找到该宠物");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "删除失败: " + e.getMessage());
        }
        return result;
    }
}    